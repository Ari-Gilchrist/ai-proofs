# The Four Colour Theorem

An Isabelle/HOL port of Gonthier's fourcolor development, targeting Isabelle2026.

The public results in `Four_Colour.thy`, for `m :: rp_point region_map`, are:

- `four_color_finite`: `rp_finite_simple_map m ⟹ rp_colorable_with 4 m`.
- `four_color`: `rp_simple_map m ⟹ rp_colorable_with 4 m`.

Regions are disjoint open connected subsets of the real plane. Adjacency
requires a shared closure point incident to at most two regions. The finite
geometric construction reduces these maps to finite planar loopless hypermaps;
compactness removes the finiteness restriction. The combinatorial face- and
vertex-colouring results are in `Combinatorial/Combinatorial_Four_Colour.thy`.

## Build

From this directory, with Isabelle2026:

```sh
isabelle build -v -j 1 -o threads=2 -o browser_info -o document=pdf \
  -o 'document_variants=document:outline=/proof,/ML' -D .
```

No other AFP entry, external executable, or source generator is required.
The 17 sessions retain intermediate checker and certificate heaps to limit
memory use. A full build recomputes 633 quiz checks, 633 reducibility checks,
four score-cap checks, and seven presentation certificates. Allow several
minutes per certificate session and at least 6 GB of available RAM and swap
combined; requirements depend on the machine. The main session is `Four_Colour`.
Proof-document sources are in `document/`.

## Computation and sources

Checker soundness is proved in HOL. Concrete certificates use `eval` and shared
`code_reflect` checker code. The final theorems depend on the standard oracle
`Code_Generator.holds_by_evaluation`, trusting Isabelle's code generator and ML
runtime. Their dependency audit rejects skipped proofs and all other oracles.
No discretization, reducibility, or unavoidability premise remains assumed.

See `AUTHORS`, `NOTICE`, `LICENSE`, and `document/root.bib` for attribution and
sources. Adapted upstream material retains CeCILL-B notices; original additions
retain the repository's MIT licence. `SUBMISSION.md` contains the submission
abstract, contact, and questions for the AFP editors.
