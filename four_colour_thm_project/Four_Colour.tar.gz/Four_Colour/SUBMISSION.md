# AFP submission

- Entry name and main session: `Four_Colour`
- Title: **The Four Colour Theorem**
- Author/contact and proposed maintainer: **Ari Gilchrist**, ari.gilchrist.work@gmail.com
- Topic: Mathematics / Graph theory
- Isabelle release: Isabelle2026

## Abstract

We formalise the Four Colour Theorem in Isabelle/HOL: every simple map of the
real plane can be coloured with four colours. The development follows Gonthier's
Rocq formalisation of the Robertson–Sanders–Seymour–Thomas proof, including
reducibility of 633 configurations and the discharging argument. A geometric
construction reduces finite plane maps to finite planar hypermaps; colouring
compactness extends the result to maps with arbitrarily many regions.
Certificate checkers are proved sound in HOL, and their concrete obligations
are discharged using Isabelle's standard code-evaluation mechanism.

## Comments for the editors

The entry ports Gonthier's fourcolor development. Upstream sources and revision
are recorded in NOTICE and the bibliography. AI assistance is disclosed in
AUTHORS and the proof document.

The full Isabelle2026 build, both PDF variants, and the official AFP mandatory
linter passed on 26 November 2026, covering all 114 entry theories.

The final theorems depend on `Code_Generator.holds_by_evaluation`. Checker
soundness is proved in HOL; a dependency audit rejects skipped proofs and any
other oracle. No discretization, reducibility, or unavoidability premise remains.

Two editorial decisions are requested:

- **Sessions:** please consider an exception to the preference for a single
  session per entry. The 17 sessions, all in chapter AFP, retain intermediate
  checker and certificate heaps and separate the geometric branch to control
  memory use.
- **Licence classification:** adapted upstream material retains CeCILL-B notices;
  original additions retain the repository's MIT licence. Both licence texts
  are included. Please advise how to classify the entry in AFP metadata.
  No uniform BSD/LGPL relicensing is assumed.

The source upload is `../Four_Colour.tar.gz`; the proof document is
`../Four_Colour.pdf`. Build instructions and the precise map representation are
in README.md. Author review and the editorial decisions above remain before
upload through the [AFP submission form](https://isa-afp.org/submission/).
